#' Poisson process factorization for topographic-dependent mutational signatures analysis
#'
#' @param gr_Mutations GenomicRanges object contatining covariates and samples
#' @param gr_SignalTrack Matrix containing signals for the whole genome
#' @param method Which method to use for the estimation. Available options are 'mle', 'map', 'mcmc'
#' @param bin_weight Weights to give to each region
#' @param K Upper bound to the number of signatures expected in the data
#' @param prior_params The hyperparameters of the prior.
#' @param init Initialization parameters. See \code{SigPoisProcess.init}
#' @param controls Control parameters for each method. See \code{SigPoisProcess.contol}
#'
#' @returns An object of class SigPoisProcess_mult
#' @export
#' @useDynLib SigPoisProcess, .registration = TRUE
#' @import Rcpp
#' @import RcppArmadillo
#' @importFrom magrittr %>%
SigPoisProcess_multCN <- function(gr_Mutations,
                                  SignalTrack,
                                  CopyTrack,
                                  K = 10,
                                  method = "map",
                                  prior_params = SigPoisProcess_mult.PriorParams(),
                                  controls = SigPoisProcess_mult.controls(),
                                  init = SigPoisProcess_mult.init(),
                                  verbose = FALSE,
                                  update_Signatures = TRUE,
                                  update_Theta = TRUE,
                                  update_Betas = TRUE){

  # Extract copy number
  #copy_number <- gr_Mutations$copy_number
  #gr_Mutations$copy_number <- NULL
  # Extract the data and the covariates
  X <- as.data.frame(GenomicRanges::mcols(gr_Mutations)) %>%
    dplyr::select(where(is.numeric)) %>%
    as.matrix()

  # Check that colnames of SignalTrack and colnames of X match
  if(any(colnames(SignalTrack) != colnames(X))){
    stop("Must have colnames(SignalTrack) == colnames(X))")
  }

  # Extract the matrix of aggregated mutations
  MutMatrix <- getTotalMutations(gr_Mutations)

  # Shuffle copy tracks
  CopyTrack <- CopyTrack[, colnames(MutMatrix)]

  # Extract mutation data
  Mutations <- as.data.frame(GenomicRanges::mcols(gr_Mutations)) %>%
    dplyr::select(sample, channel)
  Mutations$sample <- as.factor(Mutations$sample) #, levels = unique(Mutations$sample))
  Mutations$channel <- as.factor(Mutations$channel)

  # Extract channel ID and mutation ID
  channel_id <- as.numeric(Mutations$channel)
  sample_id <- as.numeric(Mutations$sample)

  #----------------------------------------------- Model dimensions
  I <- length(levels(Mutations$channel)) # Number of mutational channels
  J <- length(unique(sample_id)) # Number of patients
  p <- ncol(SignalTrack) # Number of covariates (excluding the intercept)
  N <- nrow(Mutations) # Total number of mutations

  ## ----------------------------------------------- Model settings
  prior_params <- do.call("SigPoisProcess_mult.PriorParams", prior_params)
  a <- prior_params$a
  alpha <- prior_params$alpha
  epsilon <- prior_params$epsilon
  if (is.null(prior_params$a0) | is.null(prior_params$b0)) {
    a0 <- a * J + 1
    b0 <- epsilon * a * J
  } else {
    a0 <- prior_params$a0
    b0 <- prior_params$b0
  }

  #---- Shrinkage method
  shrinkage <- "mu_sigma"
  if (is.null(prior_params$c0) | is.null(prior_params$d0)) {
    c0 <- K / 2 + 1
    d0 <- epsilon * K / 2
  } else {
    c0 <- prior_params$c0
    d0 <- prior_params$d0
  }

  #----------------------------------------------- Prior for the signatures
  SigPrior <- prior_params$SigPrior
  if (!is.null(SigPrior)) {
    if (!is.matrix(SigPrior)) {
      stop("SigPrior must be a matrix")
    }
    if (length(setdiff(rownames(SigPrior), levels(Mutations$channel))) > 0) {
      stop("Must have rownames(SigPrior) equal to levels(Mutations$channel)")
    }
    Kpre <- ncol(SigPrior)
    SigPrior <- SigPrior[levels(Mutations$channel), ] # reorder
    if (K > 0) {
      SigPrior_new <- matrix(alpha, nrow = I, ncol = K)
      colnames(SigPrior_new) <- paste0("SigN", sprintf("%02d", 1:K))
      rownames(SigPrior_new) <- rownames(SigPrior)
      SigPrior <- cbind(SigPrior, SigPrior_new)
      K <- Kpre + K
    } else {
      K <- Kpre
    }
  } else {
    SigPrior <- matrix(alpha, nrow = I, ncol = K)
    colnames(SigPrior) <- paste0("SigN", sprintf("%02d", 1:K))
    rownames(SigPrior) <- levels(Mutations$channel)
  }

  #----------------------------------------------- Initial values
  # Initialize the model
  init <- do.call("SigPoisProcess_mult.init", init)
  #---- Initial value for the signatures
  if(is.null(init$R_start)){
    R_start <- sample_signatures(SigPrior)
  } else {
    R_start <- init$R_start
    if(ncol(R_start) != K){
      stop("ncol(R_start) must be equal to specified K")
    }
  }
  #---- Initial value for the baseline loadings
  if(is.null(init$Theta_start)){
    Area_patients <- colSums(CopyTrack)
    Theta_start <- matrix(rgamma(J * K, colSums(MutMatrix)), nrow = K, byrow = TRUE)#/sum(bin_weight)
    Theta_start <- Theta_start / t(Area_patients)[rep(1, K), ]
  } else {
    Theta_start <- init$Theta_start
  }
  #---- Initial value for the relevance weights
  if(is.null(init$Mu_start)){
    Mu_start <- rowMeans(Theta_start)#1 / rgamma(K, a * J  + 1, epsilon * a * J)
  } else {
    Mu_start <- init$Mu_start
  }

  #---- Initial value for the variances
  if(is.null(init$Sigma2_start)){
    Sigma2_start <- rep(d0/(c0 + 1), K)#1 / rgamma(K, a * J  + 1, epsilon * a * J)
  } else {
    Sigma2_start <- init$Sigma2_start
  }

  #---- Initial value for the regression coefficients (start at 0)
  if(is.null(init$Betas_start)){
    Betas_start <- matrix(rnorm(p * K, mean = 0, sd = 1e-7), nrow = p, ncol = K)#matrix(0, nrow = p, ncol = K)
  } else {
    Betas_start <- init$Betas_start
  }

  #----------------------------------------------- Control parameters for the model
  if (!method %in% c("mle", "map", 'mcmc')) {
    stop("method must be either 'map', 'mle' or 'mcmc'")
  }
  controls <- do.call("SigPoisProcess_mult.controls", controls)

  #----------------------------------------------- Estimate the model
  # List to append results
  results <- list(sol = NULL, method = method, chain = NULL)

  ######################################################
  # Optimization
  ######################################################
  if(method == "map") {
    if(verbose){
      cat("Start Optimization \n")
    }
    maxiter <- controls$maxiter
    n_iter_betas <- controls$n_iter_betas
    tol <- controls$tol
    # Find the MLE using the multiplicative rules
    out <- .PoissonProcess_optim_CN(R_start = R_start,
                                    Theta_start = Theta_start,
                                    Betas_start = Betas_start,
                                    Mu_start = Mu_start,
                                    Sigma2_start = Sigma2_start,
                                    X = X,
                                    SignalTrack = SignalTrack,
                                    CopyTrack = CopyTrack,
                                    channel_id = channel_id - 1,
                                    sample_id = sample_id - 1,
                                    SigPrior = SigPrior,
                                    a = a,
                                    a0 = a0,
                                    b0 = b0,
                                    c0 = c0,
                                    d0 = d0,
                                    shrinkage = shrinkage,
                                    update_R = update_Signatures,
                                    update_Theta = update_Theta,
                                    update_Betas = update_Betas,
                                    method = method,
                                    maxiter = maxiter,
                                    n_iter_betas = n_iter_betas,
                                    tol = tol,
                                    verbose = verbose)

    #--- Postprocess results
    # Signatures
    Sigs <- out$R
    colnames(Sigs) <- colnames(SigPrior)
    rownames(Sigs) <- rownames(SigPrior)
    # Loadings
    Thetas <- out$Theta
    rownames(Thetas) <- colnames(SigPrior)
    colnames(Thetas) <- colnames(MutMatrix)
    # Coefficients
    Betas <- out$Betas
    dimnames(Betas) <- list(colnames(X), colnames(SigPrior))

    #---- Store results in a list
    results$sol <- out
  }


  ######################################################
  # MCMC
  ######################################################
  if(method == "mcmc") {
    if(verbose){
      cat("Start MCMC solution \n")
    }
    nsamples <- controls$nsamples
    burnin <- controls$burnin
    out <- .PoissonProcess_BayesCN(R_start = R_start,
                                   Theta_start = Theta_start,
                                   Betas_start = Betas_start,
                                   Mu_start = Mu_start,
                                   Sigma2_start = Sigma2_start,
                                   X = X,
                                   SignalTrack = SignalTrack,
                                   CopyTrack = CopyTrack,
                                   nsamples = nsamples,
                                   burn_in = burnin,
                                   channel_id = channel_id - 1,
                                   sample_id = sample_id - 1,
                                   SigPrior = SigPrior,
                                   update_R = update_Signatures,
                                   update_Theta = update_Theta,
                                   update_Betas = update_Betas,
                                   a = a,
                                   a0 = a0,
                                   b0 = b0,
                                   c0 = c0,
                                   d0 = d0,
                                   verbose = verbose)

    # Add dimension names
    dimnames(out$SIGSchain) <- list(NULL,  rownames(SigPrior), colnames(SigPrior))
    dimnames(out$THETAchain) <- list(NULL,  colnames(SigPrior), colnames(MutMatrix))
    dimnames(out$BETASchain) <- list(NULL,  colnames(X), colnames(SigPrior))
    dimnames(out$MUchain) <- list(NULL, colnames(SigPrior))
    dimnames(out$SIGMA2chain) <- list(NULL, colnames(SigPrior))

    #--- Postprocess results
    # Signatures
    Sigs <- apply(out$SIGSchain[-c(1:burnin), , ], c(2,3), mean)
    # Loadings
    Thetas <- apply(out$THETAchain[-c(1:burnin), , ], c(2,3), mean)
    # Coefficients
    Betas <- apply(out$BETASchain[-c(1:burnin), , ], c(2,3), mean)
    # Mu and sigma
    Mu <- colMeans(out$MUchain[-c(1:burnin), ])
    Sigma2 <- colMeans(out$SIGMA2chain[-c(1:burnin), ])

    #---- Store results in a list
    results$chain <- out
  }

  #---- Store results in a list
  results$Thetas <- Thetas
  results$Signatures <- Sigs
  results$Betas <- Betas

  if(method == "map"){
    results$Mu <- c(out$Mu)
    names(results$Mu) <- colnames(SigPrior)
    results$Sigma2 <- c(out$Sigma2)
    names(results$Sigma2) <- colnames(SigPrior)
  } else if (method == "mcmc") {
    results$Mu <- Mu
    results$Sigma2 <- Sigma2
  } else {
    results$Mu <- NULL
    results$Sigma2 <- NULL
  }

  results$init <- list(R_start = R_start,
                       Theta_start = Theta_start,
                       Betas_start = Betas_start,
                       Mu_start = Mu_start,
                       Sigma2_start = Sigma2_start)

  results$PriorParams <- list(a = a, alpha = alpha, epsilon = epsilon,
                              a0 = a0, b0 = b0, c0 = c0, d0 = d0,
                              SigPrior = SigPrior)

  results$controls <- controls

  class(results) <- "SigPoisProcess_mult"
  return(results)
}


#---- Initialization functions
#' @export
SigPoisProcess_mult.PriorParams <- function(a = 1.01, alpha = 1.01,
                                            epsilon = 0.001,
                                            a0 = NULL,
                                            b0 = NULL,
                                            c0 = 100,
                                            d0 = 1,
                                            shrinkage = "none",
                                            SigPrior = NULL){
  list(a = a, alpha = alpha, epsilon = epsilon,
       a0 = a0, b0 = b0, c0 = c0, d0 = d0,
       shrinkage = shrinkage,
       SigPrior = SigPrior)
}


#' @export
SigPoisProcess_mult.controls <- function(nsamples = 2000,
                                         burnin = 2000,
                                         maxiter = 5000,
                                         n_iter_betas = 2,
                                         tol = 1e-6,
                                         ncores = 1){
  list(nsamples = nsamples, burnin = burnin,
       maxiter = maxiter, tol = tol,
       ncores = ncores, n_iter_betas = n_iter_betas)
}

#' @export
SigPoisProcess_mult.init <- function(R_start = NULL,
                                     Theta_start = NULL,
                                     Betas_start = NULL,
                                     Mu_start = NULL,
                                     Sigma2_start = NULL){
  list(R_start = R_start,
       Theta_start = Theta_start,
       Betas_start = Betas_start,
       Mu_start = Mu_start,
       Sigma2_start = Sigma2_start)
}

plot.SigPoisProcess <- function(object){
  p_sig <- plot_96SBSsig(object$Signatures, remove_strip_text_y = TRUE)
  p_Loads <- plot_avgLoads(object$Betas, object$Xbar, object$AttrSummary)
  p_sig + p_Loads
}

#' @export
plot_96SBSsig <- function(signatures,
                          lowCI = NULL,
                          highCI = NULL,
                          returnList = FALSE,
                          remove_strip_text_y = FALSE,
                          palette = c("#40BDEE", "#020202", "#E52925", "#CCC9CA", "#A3CF62", "#ECC5C5")) {
  signatures <- as.matrix(signatures)
  names_sig <- rownames(signatures)
  df_plot <- data.frame(signatures) %>%
    dplyr::mutate(Channel = names_sig,
                  Triplet = apply(stringr::str_split(names_sig, "", simplify = TRUE), 1,
                                  function(x) paste0(x[c(1,3,7)], collapse = "")),
                  Mutation = apply(stringr::str_split(names_sig, "", simplify = TRUE), 1,
                                   function(x) paste0(x[c(3,4,5)], collapse = "")),
                  Mutation = as.factor(Mutation)) %>%
    tidyr::gather(key = "Sig", value = "Prob", -Channel, -Triplet, -Mutation)

  if(!is.null(lowCI) & !is.null(highCI)){
    df_plot <- df_plot %>%
      dplyr::left_join(data.frame(lowCI) %>%
                         dplyr::mutate(Channel = names_sig,
                                       Triplet = apply(stringr::str_split(names_sig, "", simplify = TRUE), 1,
                                                       function(x) paste0(x[c(1,3,7)], collapse = "")),
                                       Mutation = apply(stringr::str_split(names_sig, "", simplify = TRUE), 1,
                                                        function(x) paste0(x[c(3,4,5)], collapse = "")),
                                       Mutation = as.factor(Mutation)) %>%
                         gather(key = "Sig", value = "lowCI", -Channel, -Triplet, -Mutation),
                       by = c("Channel", "Triplet", "Mutation", "Sig")) %>%
      dplyr::left_join(data.frame(highCI) %>%
                         dplyr::mutate(Channel = names_sig,
                                       Triplet = apply(stringr::str_split(names_sig, "", simplify = TRUE), 1,
                                                       function(x) paste0(x[c(1,3,7)], collapse = "")),
                                       Mutation = apply(stringr::str_split(names_sig, "", simplify = TRUE), 1,
                                                        function(x) paste0(x[c(3,4,5)], collapse = "")),
                                       Mutation = as.factor(Mutation)) %>%
                         gather(key = "Sig", value = "highCI", -Channel, -Triplet, -Mutation),
                       by = c("Channel", "Triplet", "Mutation", "Sig"))
  }

  p_list <- vector(mode = "list", length = ncol(signatures))
  for(j in 1:length(p_list)){
    p <-   ggplot2::ggplot(df_plot %>% dplyr::filter(Sig == colnames(signatures)[j]),
                           aes(x = Triplet, y = Prob, fill = Mutation))+
      geom_bar(stat = "identity", width = 0.65) +
      #geom_hline(yintercept = -0.001)+
      #geom_segment(x = 1, xend = 1, y = -0.01, yend = Inf, linewidth = 0.3)+
      facet_grid(Sig~Mutation, scales = "free")+
      theme_minimal()+
      scale_fill_manual(values = palette)+
      theme(legend.position = "none",
            axis.title = element_blank(),
            axis.ticks = element_blank(),
            axis.text.y = element_blank(),
            plot.margin = margin(1, 1, 1, 1),
            #axis.text.x = element_text(angle = 90, color = "gray35",
            #                          vjust = .5, size = 6.5, margin = margin(t = -4)),
            axis.text.x = element_blank(),
            panel.grid = element_blank(),
            panel.spacing.x=unit(0.1, "lines"),
            panel.spacing.y=unit(0,"lines"),
            strip.background=element_blank(),
            axis.line.x.bottom = element_line(linewidth = 0.2),
            axis.line.y.left = element_line(linewidth = 0.2),
            strip.text.x = element_blank())
    if(!is.null(lowCI) & !is.null(highCI)){
      p <- p +
        geom_linerange(aes(x = Triplet, ymin =lowCI, ymax = highCI), color = "grey65")
    }
    if(remove_strip_text_y){
      p <- p + theme(strip.text.y = element_blank())
    }
    p_list[[j]]  <- p
  }
  if(returnList){
    return(p_list)
  }
  p_all <- ggpubr::ggarrange(plotlist = p_list, ncol = 1, common.legend = TRUE, legend = "none")
  return(p_all)
}
